# kex-macro
iOS 11.2.1 WIP Jailbreak 

# Credits:
[JohnVS](https://twitter.com/Johnsbell3), [AeroPwn](https://twitter.com/AeroPwn), and [iSn0w](https://twitter.com/iSn0we)
# What is this?
A work in progress jailbreak (probably wont become a full jailbreak) this is just a test project unless released.
# Lol
same